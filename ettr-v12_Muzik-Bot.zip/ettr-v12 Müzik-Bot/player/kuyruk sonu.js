module.exports = (client, message, queue) => {
    message.channel.send(`${client.emotes.error} - Sırada şarkı yok bende sustum  !`);
};